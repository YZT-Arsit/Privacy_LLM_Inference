# TEE ↔ GPU protocol demo (boundary_client)

- boundary_backend: `process`
- gpu_backend: `mock`
- max_new_tokens: 64
- **tee_used_on_gpu: False**
- boundary_calls: `{'embed_and_mask': 64, 'recover_logits': 64, 'sample': 64}`
- gpu_calls: `{'BoundaryInitRequest': 1, 'MaskedPrefillRequest': 1, 'MaskedDecodeRequest': 63}`
- trusted_bytes: 512,608
- gpu_bytes: 1,574,400
- tokens_match_plaintext_reference: True

## Security audit

- audit_performed: True
- **audit_passed: True**
- gpu_visible_plaintext_fields: none
- leaked_secret_fields: none
- wrong_mask_control: `{'correct_max_abs_err': 5.960464477539063e-08, 'wrong_max_abs_err': 0.7952526807785034, 'plaintext_logit_scale': 0.36217018961906433, 'wrong_rel_err': 2.195798283715624, 'correct_recovers_plaintext': True, 'wrong_mask_diverges': True, 'correct_token_match': True, 'wrong_token_match': False, 'findings': []}`

## Boundary attestation (TDX)

- boundary_tee_type: `tdx`
- **boundary_attested: True**
- quote_status: `verified`
- expected_runtime_hash: `96e4353736e4cf2e133b9efac0a6fcf6337eab8ecdd5d6c2d413578072d133de392763f928da926bccd726716e694c7b1cc2b7b3a06a3c5aaabe6c40979220a5`
- evidence_report_data: `96e4353736e4cf2e133b9efac0a6fcf6337eab8ecdd5d6c2d413578072d133de392763f928da926bccd726716e694c7b1cc2b7b3a06a3c5aaabe6c40979220a5`
- **runtime_hash_bound: True**
- binding_mismatch_reason: none
- runtime_manifest_path: `None` (files=8)
- mr_td: `e0199499baacb2e4f4bc73046f25bedf674d42defbe4e854242bd6554a9d155edf7f3bff8e6202e63ed230e59ab2568a`
- debug: False
- jwt_present: True (parts=3)
- mr_td_match: True

## Cross-machine scope (keep these separate)

- model_name: `mock-identity`
- cross_machine_compute: **end_to_end**
- gpu_worker_remote: True (`http://127.0.0.1:18080`)
- teacher_forced_top1_match_rate: None
- plain_vs_masked_token_match_rate: None
- compute correctness: standalone H800 E1/E2 (run_qwen7b_e1_nolora_generation.py / run_qwen7b_e2_token_scaling.py) validates full Qwen2.5-7B masked compute correctness, generation behaviour, and token scaling
- security boundary: cross-machine mock end-to-end (real attestation + wire-field rejection + masked-tensor-only traffic + audit) plus the qwen7b /init handshake plus TDX boundary attestation validates the attested trusted boundary driving a remote untrusted GPU worker
- connectivity: cross-machine connectivity is the deployment setting for the attested protocol, not a contribution
- **limitations**: none for the boundary security claim: the mock identity decoder validates the full cross-machine attested protocol + audit end-to-end; Qwen compute correctness is the standalone E1/E2 result

_The GPU worker received only masked embeddings + public metadata + the folded LM head, and returned only masked logits. The model is never placed in the TEE._
