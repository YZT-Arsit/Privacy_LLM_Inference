# Final TDX Attested Protocol Summary

## TDX Attestation

- TD Quote generation: success
- Alibaba Cloud Attestation API verification: success
- Returned token: signed JWT / EAT
- TEE type: tdx
- TD debug attribute: false
- MR_TD: e0199499baacb2e4f4bc73046f25bedf674d42defbe4e854242bd6554a9d155edf7f3bff8e6202e63ed230e59ab2568a
- Runtime hash binding: success

## Runtime Hash

- Runtime hash:
  de3fa0bc972fdf418e6877b507195c3844877857c1038950e6d325e0614a01ed8aabc88cf5f29c6157a3236be6a5a89a9850f4e8b8341c8558c7e90abc15dffe
- The attestation token report_data matches this runtime hash.

## Protocol Demo

- audit_passed: true
- boundary_tee_type: tdx
- boundary_attested: true
- runtime_hash_bound: true
- gpu_visible_plaintext_fields: []
- leaked_secret_fields: []
- tee_used_on_gpu: false
- boundary_calls:
  - embed_and_mask: 4
  - recover_logits: 4
  - sample: 4
- trusted_bytes: 32128
- gpu_bytes: 1063680

## Interpretation

The trusted boundary is attested by Alibaba Cloud TDX remote attestation. The returned attestation token is bound to the runtime hash used by the protocol demo. The untrusted GPU worker receives only protocol-visible masked data and does not observe plaintext prompt fields, token ids, generated tokens, recovered logits, or mask secrets.
