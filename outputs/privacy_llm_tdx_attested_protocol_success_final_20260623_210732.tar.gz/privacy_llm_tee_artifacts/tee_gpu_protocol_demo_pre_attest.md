# TEE ↔ GPU protocol demo (local_two_process)

- boundary_backend: `process`
- gpu_backend: `mock`
- max_new_tokens: 4
- **tee_used_on_gpu: False**
- boundary_calls: `{'embed_and_mask': 4, 'recover_logits': 4, 'sample': 4}`
- gpu_calls: `{'BoundaryInitRequest': 1, 'MaskedPrefillRequest': 1, 'MaskedDecodeRequest': 3}`
- trusted_bytes: 32,128
- gpu_bytes: 1,063,680
- tokens_match_plaintext_reference: True

## Security audit

- audit_performed: True
- **audit_passed: True**
- gpu_visible_plaintext_fields: none
- leaked_secret_fields: none
- wrong_mask_control: `{'correct_max_abs_err': 5.960464477539063e-08, 'wrong_max_abs_err': 0.7952526807785034, 'plaintext_logit_scale': 0.36217018961906433, 'wrong_rel_err': 2.195798283715624, 'correct_recovers_plaintext': True, 'wrong_mask_diverges': True, 'correct_token_match': True, 'wrong_token_match': False, 'findings': []}`

## Boundary attestation (TDX)

- boundary_tee_type: `tdx`
- **boundary_attested: False**
- quote_status: `tdx_guest_present_evidence_not_provided`
- runtime_hash: `4d76a7adf9066b0cfaf59ce1a1fe4313f97cfd3247e9b6e6e3dea1fa9253d3ef53dfc75f30b1d2f4e2a93b7ea0f43f96b21d1e691fc6c8fefce051aea8b2f63e`
- runtime_hash_bound: None
- runtime_manifest_path: `/root/privacy_llm_tee_artifacts/trusted_runtime_manifest.json` (files=8)
- mr_td: `None`
- debug: None
- jwt_present: False (parts=0)
- mr_td_match: None

_The GPU worker received only masked embeddings + public metadata + the folded LM head, and returned only masked logits. The model is never placed in the TEE._
