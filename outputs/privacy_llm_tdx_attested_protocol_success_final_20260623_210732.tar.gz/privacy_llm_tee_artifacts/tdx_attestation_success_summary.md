# Alibaba Cloud TDX Attestation Success Summary

## Result

TDX remote attestation succeeded on Alibaba Cloud.

## Evidence

- TD Quote generation: success
- Alibaba Cloud Attestation API verification: success
- Returned token format: JWT, 3 parts
- JWT algorithm: RS256
- TEE type: tdx
- TD debug attribute: false
- Runtime hash binding: success
- report_data matches runtime_hash_64bytes.hex: true

## Key Claims

- issuer: https://attest.cn-beijing.aliyuncs.com
- audience: https://attest.cn-beijing.aliyuncs.com
- tee: tdx
- debug: false
- septve_disable: true

## Interpretation

The trusted boundary runtime manifest hash was placed into TD report_data. The returned attestation token contains the same report_data value, confirming that the remote attestation result is bound to the trusted runtime manifest.
