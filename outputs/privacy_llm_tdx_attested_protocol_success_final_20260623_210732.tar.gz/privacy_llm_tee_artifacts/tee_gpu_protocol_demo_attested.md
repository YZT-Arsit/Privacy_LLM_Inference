# TEE ↔ GPU protocol demo (local_two_process)

- boundary_backend: `process`
- gpu_backend: `mock`
- max_new_tokens: 4
- **tee_used_on_gpu: False**
- boundary_calls: `{'embed_and_mask': 4, 'recover_logits': 4, 'sample': 4}`
- gpu_calls: `{'BoundaryInitRequest': 1, 'MaskedPrefillRequest': 1, 'MaskedDecodeRequest': 3}`
- trusted_bytes: 32,128
- gpu_bytes: 1,063,680
- tokens_match_plaintext_reference: True

## Security audit

- audit_performed: True
- **audit_passed: True**
- gpu_visible_plaintext_fields: none
- leaked_secret_fields: none
- wrong_mask_control: `{'correct_max_abs_err': 5.960464477539063e-08, 'wrong_max_abs_err': 0.7952526807785034, 'plaintext_logit_scale': 0.36217018961906433, 'wrong_rel_err': 2.195798283715624, 'correct_recovers_plaintext': True, 'wrong_mask_diverges': True, 'correct_token_match': True, 'wrong_token_match': False, 'findings': []}`

## Boundary attestation (TDX)

- boundary_tee_type: `tdx`
- **boundary_attested: False**
- quote_status: `evidence_check_failed`
- runtime_hash: `de3fa0bc972fdf418e6877b507195c3844877857c1038950e6d325e0614a01ed8aabc88cf5f29c6157a3236be6a5a89a9850f4e8b8341c8558c7e90abc15dffe`
- runtime_hash_bound: False
- runtime_manifest_path: `None` (files=8)
- mr_td: `e0199499baacb2e4f4bc73046f25bedf674d42defbe4e854242bd6554a9d155edf7f3bff8e6202e63ed230e59ab2568a`
- debug: False
- jwt_present: True (parts=3)
- mr_td_match: True

_The GPU worker received only masked embeddings + public metadata + the folded LM head, and returned only masked logits. The model is never placed in the TEE._
