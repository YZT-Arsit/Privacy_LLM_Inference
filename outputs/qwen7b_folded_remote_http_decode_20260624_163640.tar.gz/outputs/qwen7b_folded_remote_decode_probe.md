# Cross-machine package-backed decode (qwen7b_folded_remote_package_decode)

- model_name=`Qwen2.5-7B-Instruct`  seq_len=39  dtype=bfloat16  seed=2035  max_new_tokens=4
- gpu_worker_remote=True  url=`http://127.0.0.1:18082`  gpu_backend=`qwen7b_folded_package`
- folded_package_path=`/root/autodl-tmp/privacy_llm_packages/qwen7b_folded_full`  num_shards=29  package_size_gb=26.339369
- manifest_hash=`90184a6bf33cfa058419085096b938e63f1ed1a00b2143131d6618a19a21e1d8`
- **folded_package_loaded=True** **folded_package_valid=True**
- **package_backed_prefill=True** **package_backed_decode=True**
- **worker_has_mask_secrets=False** **tee_used_on_gpu=False**

## Generated tokens (remote package vs in-process reference)

- reference_token_ids=[47832, 374, 264, 9023]
- package_token_ids=[47832, 374, 264, 9023]
- **tokens_exact_match=True**  token_match_rate=1.0000

## Security audit + accounting

- audit_performed=True  **audit_passed=True**
- gpu_visible_plaintext_fields=[]  leaked_secret_fields=[]
- boundary_calls=`{'init': 1, 'prefill': 1, 'mask_token_embedding': 3, 'decode': 3}`  gpu_calls=`{'BoundaryInitRequest': 1, 'MaskedPrefillRequest': 1, 'MaskedDecodeRequest': 3}`
- trusted_bytes=2433336  gpu_bytes=3035136  latency_s=59.09873705729842  peak_gpu_memory_mb=2140.5302734375

_cross-machine package-backed masked prefill+decode: the trusted boundary sent only masked embeddings + public model/RoPE metadata; the untrusted worker executed the folded shards (no mask secrets, tee_used_on_gpu=False). TDX attestation is NOT claimed by this run -- rerun the attested demo on TDX if the measured trusted files changed._
