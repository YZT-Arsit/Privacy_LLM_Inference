# TEE boundary microbenchmark

- backend: **process** | hidden_size: **2048** | vocab_size: **151936** | repeats: **20**
- `total_latency_ms` = embed+recover+sample (per-step trusted boundary cost); `setup_latency_ms` is a one-time cost.

| batch_size | seq_len | setup_latency_ms | embed_and_mask_latency_ms | recover_logits_latency_ms | sampling_latency_ms | total_latency_ms | trusted_input_bytes | trusted_output_bytes | released_to_untrusted_bytes | received_from_untrusted_bytes |
|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 64 | 13.878891 | 0.594302 | 1.017392 | 0.365382 | 1.977076 | 512 | 8 | 524288 | 607744 |
| 4 | 64 | 13.723046 | 8.452069 | 8.833619 | 3.032757 | 20.318445 | 2048 | 32 | 2097152 | 2430976 |
| 8 | 64 | 13.688859 | 21.862413 | 15.423211 | 6.177907 | 43.463531 | 4096 | 64 | 4194304 | 4861952 |
| 1 | 128 | 13.733834 | 1.596344 | 1.03348 | 0.368729 | 2.998553 | 1024 | 8 | 1048576 | 607744 |
| 4 | 128 | 13.718931 | 22.716217 | 9.427929 | 2.448791 | 34.592937 | 4096 | 32 | 4194304 | 2430976 |
| 8 | 128 | 13.729476 | 48.334563 | 15.252434 | 5.278479 | 68.865476 | 8192 | 64 | 8388608 | 4861952 |

