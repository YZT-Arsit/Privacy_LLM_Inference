# Alibaba Cloud TDX Trusted Boundary Experiment

## Environment

The experiment was executed inside an Alibaba Cloud Intel TDX confidential VM.

Confirmed TDX evidence:
- `/dev/tdx_guest` exists.
- `tdx_report_parse` succeeds.
- TD attributes include `NO_DEBUG` and `SEPT_VE_DISABLE`.
- TDREPORT can be generated.
- Full remote Quote generation is pending vendor-side clarification of the platform QGS / evidence path.

## What is measured

This benchmark measures only trusted boundary operations inside the TDX VM:

- plaintext `input_ids` handling
- mask seed / mask handle management
- embedding-boundary masking
- masked-logit recovery
- trusted greedy token selection
- process-boundary IPC overhead

The benchmark does not execute the full transformer inside TEE.

## Trusted / Untrusted split

Trusted TDX side:
- input boundary
- mask secret management
- embedding masking boundary
- logits recovery
- final token selection

Untrusted GPU side:
- masked decoder blocks
- masked attention
- masked MLP
- masked KV cache
- masked LM head
- large matrix multiplications

## Generated outputs

- `aliyun_tdx_boundary_microbench_process.json`
- `aliyun_tdx_boundary_microbench_process.csv`
- `aliyun_tdx_boundary_microbench_process.md`
- `aliyun_tdx_boundary_microbench_simulated.json`
- `aliyun_tdx_boundary_microbench_simulated.csv`
- `aliyun_tdx_boundary_microbench_simulated.md`

## Paper-safe statement

We deploy the trusted boundary on an Alibaba Cloud Intel TDX confidential VM. The VM exposes `/dev/tdx_guest` and successfully generates TDREPORTs with `NO_DEBUG` attributes. We execute trusted-boundary microbenchmarks inside this TDX VM. The transformer decoder, KV cache, MLP, attention, and masked LM head remain on the untrusted GPU and are evaluated separately.
