# TEE boundary microbenchmark

- backend: **simulated** | hidden_size: **2048** | vocab_size: **151936** | repeats: **20**
- `total_latency_ms` = embed+recover+sample (per-step trusted boundary cost); `setup_latency_ms` is a one-time cost.

| batch_size | seq_len | setup_latency_ms | embed_and_mask_latency_ms | recover_logits_latency_ms | sampling_latency_ms | total_latency_ms | trusted_input_bytes | trusted_output_bytes | released_to_untrusted_bytes | received_from_untrusted_bytes |
|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 64 | 14.019422 | 0.240889 | 0.435671 | 0.009107 | 0.685667 | 512 | 8 | 524288 | 607744 |
| 4 | 64 | 13.538238 | 1.97401 | 3.509428 | 0.509946 | 5.993384 | 2048 | 32 | 2097152 | 2430976 |
| 8 | 64 | 13.607433 | 6.778915 | 5.13521 | 1.703417 | 13.617542 | 4096 | 64 | 4194304 | 4861952 |
| 1 | 128 | 13.52707 | 0.718217 | 0.433141 | 0.009065 | 1.160423 | 1024 | 8 | 1048576 | 607744 |
| 4 | 128 | 13.291918 | 7.360221 | 3.527946 | 0.505849 | 11.394016 | 4096 | 32 | 4194304 | 2430976 |
| 8 | 128 | 13.507444 | 19.605729 | 5.140971 | 1.705041 | 26.451741 | 8192 | 64 | 8388608 | 4861952 |

