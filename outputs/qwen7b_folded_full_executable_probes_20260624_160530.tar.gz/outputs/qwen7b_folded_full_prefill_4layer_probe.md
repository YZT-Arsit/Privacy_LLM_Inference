# Package-backed prefill probe (k=4, dry_run=False)

- model_name=`Qwen2.5-7B-Instruct`  seq_len=39  dtype=bfloat16  seed=2035
- folded_package_path=`/root/autodl-tmp/privacy_llm_packages/qwen7b_folded_full`
- **folded_package_loaded=True**  **folded_package_valid=True**  **package_backed_prefill=True**
- num_exec_layers=4 / num_package_layers=28  num_shards=29  package_size_gb=26.339369
- manifest_hash=`90184a6bf33cfa058419085096b938e63f1ed1a00b2143131d6618a19a21e1d8`
- **worker_has_mask_secrets=False**  **tee_used_on_gpu=False**

## Correctness (package vs in-process folded reference)

- **allclose=True** (atol=0.001 rtol=0.001)
- max_abs_error=4.395e-03
- mean_abs_error=7.063e-07
- relative_l2_error=5.901e-07
- latency_s=1.0533428192138672  peak_gpu_memory_mb=21817.85
- gpu_visible_plaintext_fields=[]  leaked_secret_fields=[]

_The worker streamed 4 folded shards over the masked input; it held no masks. The down projection is pre-folded in each shard._
