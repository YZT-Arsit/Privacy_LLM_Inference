# Package-backed one-step logits probe (n=28, dry_run=False)

- model_name=`Qwen2.5-7B-Instruct`  seq_len=39  dtype=bfloat16  seed=2035
- folded_package_path=`/root/autodl-tmp/privacy_llm_packages/qwen7b_folded_full`  num_shards=29  package_size_gb=26.339369
- manifest_hash=`90184a6bf33cfa058419085096b938e63f1ed1a00b2143131d6618a19a21e1d8`
- **folded_package_loaded=True** **folded_package_valid=True** **package_backed_prefill=True** **package_backed_head=True**
- **worker_has_mask_secrets=False** **tee_used_on_gpu=False**

## Recovered-logits agreement (package vs in-process reference)

- logits_max_abs_error=3.815e-05
- logits_mean_abs_error=3.935e-06
- logits_relative_l2_error=1.904e-06
- **top1_match=True**  **next_token_match=True**  topk_overlap=1.0000 (k=5)
- allclose=True  latency_s=7.709936793893576  peak_gpu_memory_mb=23117.19
- gpu_visible_plaintext_fields=[]  leaked_secret_fields=[]
