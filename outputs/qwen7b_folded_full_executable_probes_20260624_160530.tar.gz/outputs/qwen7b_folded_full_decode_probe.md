# Package-backed decode probe (n=28, new=4, dry_run=False)

- model_name=`Qwen2.5-7B-Instruct`  seq_len=39  dtype=bfloat16  seed=2035
- folded_package_path=`/root/autodl-tmp/privacy_llm_packages/qwen7b_folded_full`  num_shards=29  package_size_gb=26.339369
- manifest_hash=`90184a6bf33cfa058419085096b938e63f1ed1a00b2143131d6618a19a21e1d8`
- **folded_package_loaded=True** **folded_package_valid=True** **package_backed_decode=True**
- **worker_has_mask_secrets=False** **tee_used_on_gpu=False**

## Generated tokens (package vs in-process reference)

- reference_token_ids=[47832, 374, 264, 9023]
- package_token_ids=[47832, 374, 264, 9023]
- **tokens_exact_match=True**  token_match_rate=1.0000
- latency_s=30.444221768528223  peak_gpu_memory_mb=23089.72
- gpu_visible_plaintext_fields=[]  leaked_secret_fields=[]
