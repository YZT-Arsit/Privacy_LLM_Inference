# E2 no-LoRA Qwen2.5-7B token scaling (dry_run=False)

- model_name=`Qwen2.5-7B-Instruct`  context_mode=**fixed_padded**  prompt_sha256_16=`8e5ff2c08122d8a6`
- seq_len_requested=128  effective_prompt_len=39  padded_seq_len=128  decode_start_index=39  attention_mask_used=True
- grid=[1, 8, 16, 32, 64]  tee_used_on_gpu=False

| max_new_tokens | tf_top1_hf_masked | tf_top1_plain_masked | greedy match | tf_logits_max_abs | tf_topk_overlap | latency_s | peak_gpu_mb | trusted_bytes | gpu_bytes |
|---|---|---|---|---|---|---|---|---|---|
| 1 | 1.0 | 1.0 | 1.0 | 0.20695018768310547 | 1.0 | 3.029958426952362 | 27279.5 | 583688 | 583680 |
| 8 | 1.0 | 1.0 | 1.0 | 0.3296966552734375 | 1.0 | 22.382633168250322 | 31535.48 | 2762816 | 2762752 |
| 16 | 1.0 | 1.0 | 1.0 | 0.34436988830566406 | 0.9875 | 44.649526219815016 | 31537.25 | 5253248 | 5253120 |
| 32 | 1.0 | 1.0 | 1.0 | 0.35480403900146484 | 0.9812500000000001 | 89.15358659625053 | 31540.78 | 10234112 | 10233856 |
| 64 | 1.0 | 1.0 | 1.0 | 0.3366966247558594 | 0.9875 | 178.2206833846867 | 31547.84 | 20195840 | 20195328 |
