# E2 no-LoRA Qwen2.5-7B token scaling (dry_run=False)

- model_name=`Qwen2.5-7B-Instruct`  context_mode=**natural_prompt**  prompt_sha256_16=`8e5ff2c08122d8a6`
- seq_len_requested=128  effective_prompt_len=39  padded_seq_len=None  decode_start_index=39  attention_mask_used=True
- grid=[1, 8, 16, 32, 64]  tee_used_on_gpu=False

| max_new_tokens | tf_top1_hf_plain | tf_top1_hf_masked | tf_top1_plain_masked | plain_vs_masked_token_match_rate | topk_overlap | logits_max_abs_error | logits_mean_abs_error | logits_relative_l2_error | latency_s | peak_gpu_memory_mb | trusted_bytes | gpu_bytes |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 1.0 | 1.0 | 1.0 | 1.0 | 1.0 | 0.20695018768310547 | 0.03708700090646744 | 0.017137080430984497 | 3.417276091873646 | 27278.74 | 583688 | 583680 |
| 8 | 1.0 | 1.0 | 1.0 | 1.0 | 1.0 | 0.3296966552734375 | 0.059149615466594696 | 0.020494261756539345 | 22.422333762049675 | 31534.73 | 2762816 | 2762752 |
| 16 | 1.0 | 1.0 | 1.0 | 1.0 | 0.9875 | 0.34436988830566406 | 0.04552488029003143 | 0.016378432512283325 | 44.79591077193618 | 31536.5 | 5253248 | 5253120 |
| 32 | 1.0 | 1.0 | 1.0 | 1.0 | 0.9812500000000001 | 0.35480403900146484 | 0.05426601320505142 | 0.020831594243645668 | 89.20993076264858 | 31540.03 | 10234112 | 10233856 |
| 64 | 1.0 | 1.0 | 1.0 | 1.0 | 0.9875 | 0.3366966247558594 | 0.041785240173339844 | 0.01521921157836914 | 178.84391939640045 | 31547.09 | 20195840 | 20195328 |
