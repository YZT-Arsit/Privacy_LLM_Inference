# E1 no-LoRA Qwen2.5-7B masked generation (dry_run=False)

- model_name=`Qwen2.5-7B-Instruct`  model_path=`/root/autodl-tmp/modelscope_cache/Qwen/Qwen2___5-7B-Instruct`
- context_mode=**fixed_padded**  prompt_sha256_16=`8e5ff2c08122d8a6`
- seq_len_requested=128  effective_prompt_len=39  padded_seq_len=128  decode_start_index=39  attention_mask_used=True
- max_new_tokens=64 num_layers=28 dtype=bfloat16
- padding_invariance_hf_token_match_rate=1.0 (ok=True)
- **tee_used_on_gpu=False**  gpu_visible_plaintext_fields=[]  leaked_secret_fields=[]
- trusted_bytes=20,195,840  gpu_bytes=20,195,328  peak_gpu_memory_mb=31547.85
- boundary_calls=`{'embed_and_mask': 64, 'recover_logits': 64, 'sample': 64}`

## Paper-critical metrics (flattened top-level)

| field | value |
|---|---|
| teacher_forced_top1_match_rate_hf_plain | 1.0 |
| teacher_forced_top1_match_rate_hf_masked | 1.0 |
| teacher_forced_top1_match_rate_plain_masked | 1.0 |
| plain_vs_masked_token_match_rate | 1.0 |
| topk_overlap | 0.9875 |
| logits_max_abs_error | 0.3366966247558594 |
| logits_mean_abs_error | 0.041785240173339844 |
| logits_relative_l2_error | 0.01521921157836914 |
| latency_s | 180.3875979669392 |
| greedy_latency_s | 180.3875979669392 |
| teacher_forced_latency_s | 4.058012332767248 |
| peak_gpu_memory_mb | 31547.85 |
| trusted_bytes | 20195840 |
| gpu_bytes | 20195328 |
| tee_used_on_gpu | False |

## Teacher-forced (main long-horizon correctness)

- steps=64
- top1 hf_plain=1.0000
- top1 hf_masked=1.0000
- top1 plain_masked=1.0000
- top5_overlap=0.9875
- logits max/mean/rel_l2 = 3.367e-01 / 4.179e-02 / 1.522e-02

## Greedy (deterministic)

- plain_vs_masked_token_match_rate=1.0
- sequence_exact_match_hf_masked=False
- logits_max_abs_error=0.00016736984252929688
- latency_s=180.388

## Sampling (temp/top_p, fixed seed)

- completion_tokens=64 temperature=0.7 top_p=0.9 seed=0
- topk_overlap=0.9844
- logits_max_abs_error=3.172e-01
- latency_s=4.021

