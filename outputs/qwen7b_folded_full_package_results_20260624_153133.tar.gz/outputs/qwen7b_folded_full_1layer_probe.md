# Qwen 1-layer folded-package probe (dry_run=False)

- model_name=`Qwen2.5-7B-Instruct`  layer_index=0  seq_len=39  dtype=bfloat16  seed=2035
- folded_package_path=`/root/autodl-tmp/privacy_llm_packages/qwen7b_folded_full`
- **folded_package_loaded=True**  **folded_package_valid=True**  num_layers=1  num_shards=29
- package_size_gb=26.339369  manifest_hash=`90184a6bf33cfa058419085096b938e63f1ed1a00b2143131d6618a19a21e1d8`
- **worker_has_mask_secrets=False**  **tee_used_on_gpu=False**

## Correctness (worker/package vs in-process protected path)

- max_abs_error=1.907e-06
- mean_abs_error=7.022e-08
- relative_l2_error=4.579e-07
- **allclose=True** (atol=0.001 rtol=0.001)
- gpu_visible_plaintext_fields=[]
- leaked_secret_fields=[]

_The worker held only folded operators (no masks) + the masked input; the down projection is pre-folded in the package. Full 28-layer shard-streamed decode remains TODO._
