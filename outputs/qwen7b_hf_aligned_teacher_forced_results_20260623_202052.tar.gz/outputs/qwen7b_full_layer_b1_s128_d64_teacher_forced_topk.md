# Qwen full-layer masked execution (memory-optimized, HF-aligned)

- model_type: **qwen2** | dry_run: **False** | TEE used: **False**
- executed_layers: **28** / total_layers: **28** | exec status: **ok**
- requested_seq_len: **128** | real_prompt_len: **59** | effective_prompt_len: **59** | decode_start_index: **59** | truncated: **False**
- **comparison status: hf_mismatch**
- hf_vs_plain: **0.328125** | hf_vs_masked: **0.328125** | plain_vs_masked: **1.0**
- exact: hf==plain **False** | hf==masked **False** | plain==masked **True**
- hf_text: `"To ensure that a privacy-preserving language model service can answer a user's question without the GPU (or any other component) ever seeing the plaintext promp"`
- masked_text: `"To ensure that a privacy-preserving language model service can answer a user's question without the GPU ever seeing the plaintext prompt or the recovered output"`

## Teacher-forced HF-prefix parity (per-step, no cascade)
- steps_evaluated: **64**
- top1 match: hf_plain **1.0** | hf_masked **1.0** | plain_masked **1.0**
- logit error (hf vs masked): avg **0.229956** max **0.41117**
- free-running: seq_exact **False** token_rate **0.328125**

