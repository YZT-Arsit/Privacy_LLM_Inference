# Qwen full-layer masked execution (memory-optimized, HF-aligned)

- model_type: **qwen2** | dry_run: **False** | TEE used: **False**
- executed_layers: **28** / total_layers: **28** | exec status: **ok**
- requested_seq_len: **128** | real_prompt_len: **59** | effective_prompt_len: **59** | decode_start_index: **59** | truncated: **False**
- **comparison status: ok**
- hf_vs_plain: **1.0** | hf_vs_masked: **1.0** | plain_vs_masked: **1.0**
- exact: hf==plain **True** | hf==masked **True** | plain==masked **True**
- hf_text: `'To'`
- masked_text: `'To'`

