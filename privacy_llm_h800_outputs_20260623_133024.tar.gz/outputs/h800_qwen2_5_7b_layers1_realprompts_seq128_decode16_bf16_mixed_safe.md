# Stage 8.2 — Real ModelScope Checkpoint Probe

- model_id: **Qwen/Qwen2.5-7B-Instruct**
- status: **ok**
- dtypes: model=**bfloat16** folding=**float32** runtime=**float32** recovery=**float32** | device: **cuda**
- cuda_available: **True** | device_name: **NVIDIA H800 PCIe**
- model_type: **qwen2** | total_layers: **28** | max_layers: **1** | partial: **True**
- hidden_size: **3584** | vocab_size: **152064**
- mask_mode: **signed_permutation** | strategy: **shared** | shared: **True**

> This stage runs bounded real ModelScope checkpoints through a masked runtime with a simulated TEE only. It does not use real TEE hardware, does not validate production generation, and claims no semantic, cryptographic, or formal security.

## Audit

- input_source: **prompt_file** | prompt_count: **8** | input_ids_shape: `[8, 128]`
- checkpoint_source: **ModelScope** | hf_remote_download_used: **False** | tokenizer_used: **True**
- layers: **1/28** | masked path used: embed=**True** blocks=**True** qkv=**True** mlp=**True** kv=**True** lm_head=**True** recovery=**True**
- negative_control: **none** | expected_to_match: **True** | negative_control_passed: **True**

## HF baseline (full model, greedy)

- latency_s: **0.709** | tokens/s: **22.567**
- new_token_ids: `[3555, 374, 279, 6722, 315, 47747, 30, 576, 6722, 315, 47747, 374, 61953, 13, 151643]`
- text_head: `'Hello, please answer briefly: What is the capital of Peru? The capital of Peru is Lima.'`

## Extracted-weight plaintext reference

- latency_s: **0.1357** | num_tokens: **17**

## Masked runtime (simulated TEE)

- token_match_rate_vs_extracted: **1.0**
- recovered_logits_max_abs_error: **1.441e-03**
- masked_logits_max_abs_error: **2.512e-03**
- latency_s (incl. reference): **2.225**

## Mixed-precision diagnostics

| metric | value |
|---|---|
| `embedding_boundary_max_abs_err` | 0.0 |
| `layer_0_input_invariant_max_abs_err` | 0.0 |
| `layer_0_output_invariant_max_abs_err` | 1.849e-04 |
| `final_norm_core_max_abs_err` | 8.450e-04 |
| `masked_logits_max_abs_err` | 2.512e-03 |
| `recovered_logits_max_abs_err` | 1.441e-03 |
| `recovered_logits_mean_abs_err` | 1.301e-05 |
| `recovered_logits_relative_l2_err` | 9.025e-06 |
| `greedy_token_match_rate` | 1.000e+00 |
| `top1_min_margin` | 2.975e-03 |
| `top1_mean_margin` | 1.160e+00 |
| `positions_with_margin_below_error` | 0/1024 |

## Boundary accounting

| metric | value |
|---|---|
| `boundary_calls` | 34 |
| `tee_to_gpu_mb` | 0.9844 |
| `gpu_to_tee_mb` | 4.9307 |
| `handoff_gemm_count` | 0 |
| `handoff_gemm_flops` | 0 |
| `logits_recovery_flops` | 5170176 |

## Peak CUDA memory (masked phase)

- allocated_mb: 20756.77 MB
- reserved_mb: 34312.0 MB
- max_allocated_mb: 32694.88 MB
- max_reserved_mb: 34312.0 MB

## Caveats

- Simulated TEE only -- no real TEE hardware is used.
- mask_mode=signed_permutation: scalable + RMSNorm-compatible but weaker than dense orthogonal masking.
- residual_mask_strategy=shared: a shared residual mask is weaker than per-layer residual masks.
- Attention scores / probabilities remain GPU-visible.
- No semantic, cryptographic, or formal security is claimed.
- Extracted-weight reference (adjacent-pair RoPE); HF forward parity is diagnostic only (RoPE/cache conventions differ).
- max_layers < total: the extracted/masked stack is a PARTIAL model; HF baseline runs the full model, so HF tokens need not match the partial-stack tokens.

