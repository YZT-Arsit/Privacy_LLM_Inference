# Stage 8.2 — Top-Conference Experiment Summary

## 1. Real checkpoint correctness
| model_id | layers | token_match_rate | recovered_logits_err | dtype |
|---|---|---|---|---|
| Qwen/Qwen2.5-0.5B-Instruct | 24/24 | 1.0 | 0.013911724090576172 | bfloat16 |
| Qwen/Qwen2.5-0.5B-Instruct | 2/24 | 1.0 | 0.00145721435546875 | bfloat16 |
| Qwen/Qwen2.5-3B-Instruct | 2/36 | 1.0 | 0.000518798828125 | bfloat16 |
| Qwen/Qwen2.5-0.5B-Instruct | 24/24 | 1.0 | 0.013911724090576172 | bfloat16 |
| Qwen/Qwen2.5-3B-Instruct | 2/36 | 1.0 | 0.000518798828125 | bfloat16 |
| Qwen/Qwen2.5-7B-Instruct | 1/28 | 1.0 | 0.0014414787292480469 | bfloat16 |

## 2. Real-prompt audit & negative controls
**Normal runs**
| model_id | input_source | prompt_count | token_match_rate | negative_control_passed |
|---|---|---|---|---|
| Qwen/Qwen2.5-0.5B-Instruct | prompt_file | 8 | 1.0 | True |
| Qwen/Qwen2.5-0.5B-Instruct | prompt_file | 8 | 1.0 | True |
| Qwen/Qwen2.5-3B-Instruct | prompt_file | 8 | 1.0 | True |
| Qwen/Qwen2.5-0.5B-Instruct | prompt_file | 8 | 1.0 | True |
| Qwen/Qwen2.5-3B-Instruct | prompt_file | 8 | 1.0 | True |
| Qwen/Qwen2.5-7B-Instruct | prompt_file | 8 | 1.0 | True |

**Negative controls (mismatch = passing)**
_(none)_

## 3. Latency / memory baseline
| model_id | layers | extracted_latency_ms | masked_latency_ms | slowdown_masked_vs_extracted | peak_mem_mb_masked |
|---|---|---|---|---|---|
| Qwen/Qwen2.5-0.5B-Instruct | 24/24 | 339.3 | 304.6 | 0.8977 | 10316.93 |
| Qwen/Qwen2.5-0.5B-Instruct | 2/24 | 85.5 | 48.6 | 0.5684 | 5411.08 |
| Qwen/Qwen2.5-3B-Instruct | 2/36 | 117.4 | 125.8 | 1.0716 | 15422.93 |
| Qwen/Qwen2.5-0.5B-Instruct | 24/24 | 323.9 | 299.3 | 0.9241 | 10316.93 |
| Qwen/Qwen2.5-3B-Instruct | 2/36 | 116.5 | 125.0 | 1.073 | 15422.93 |
| Qwen/Qwen2.5-7B-Instruct | 1/28 | 107.0 | 217.8 | 2.0355 | 29965.9 |

## 4. Output boundary ablation
| model_id | boundary_mode | gpu_visible | tee_compute_flops | transfer_bytes | token_match_rate | recovered_logits_err | latency_ms | latency_kind |
|---|---|---|---|---|---|---|---|---|
| Qwen/Qwen2.5-0.5B-Instruct | plaintext_logits | plaintext_logits | 20663296 | 41326592 | 1.0 | 0.0 | None | n/a |
| Qwen/Qwen2.5-0.5B-Instruct | masked_logits | masked_logits (vocab permutation + positive scale) | 61989888 | 41326592 | 1.0 | 0.00145721435546875 | 48.794 | measured |
| Qwen/Qwen2.5-0.5B-Instruct | hidden_to_tee | masked_hidden_state | 37090616320 | 243712 | 1.0 | 0.0 | None | analytical_cost_model |

## 5. Leakage / attack metrics
**D1 token recovery from embeddings**
| model_id | vocab_size | plaintext_top1_token_recovery | masked_top1_token_recovery | random_baseline_top1 |
|---|---|---|---|---|
| Qwen/Qwen2.5-0.5B-Instruct | 151936 | 1.0 | 0.0 | 6.58e-06 |

**D2 masked-logit alignment**
| model_id | gpu_visible_argmax_matches_plaintext | top5_overlap_plain_vs_masked_visible | rank_correlation_plain_vs_masked_visible | recovered_argmax_matches_plaintext |
|---|---|---|---|---|
| Qwen/Qwen2.5-0.5B-Instruct | 0.0 | 0.0 | 0.001207 | 1.0 |

**D3 hidden-state structural leakage**
| model_id | norm_preservation_ratio_mean | pairwise_distance_correlation | pairwise_cosine_correlation | nearest_neighbor_identity_preservation |
|---|---|---|---|---|
| Qwen/Qwen2.5-0.5B-Instruct | 1.0 | 1.0 | 1.0 | 1.0 |

## 6. Batch scaling
| model_id | batch_size | token_match_rate | latency_ms | peak_cuda_memory_mb | tokens_per_second |
|---|---|---|---|---|---|
| Qwen/Qwen2.5-0.5B-Instruct | 1 | 1.0 | 36.5 | 4447.9 | 438.356 |
| Qwen/Qwen2.5-0.5B-Instruct | 2 | 1.0 | 39.1 | 4546.78 | 818.414 |
| Qwen/Qwen2.5-0.5B-Instruct | 4 | 1.0 | 42.3 | 4751.23 | 1513.002 |
| Qwen/Qwen2.5-0.5B-Instruct | 8 | 1.0 | 48.7 | 5411.08 | 2628.337 |

## 7. Full-layer 0.5B
| model_id | layers | token_match_rate | recovered_logits_err |
|---|---|---|---|
| Qwen/Qwen2.5-0.5B-Instruct | 24/24 | 1.0 | 0.013911724090576172 |
| Qwen/Qwen2.5-0.5B-Instruct | 24/24 | 1.0 | 0.013911724090576172 |

## 8. 3B / 7B scalability
| model_id | layers | token_match_rate | recovered_logits_err | masked_latency_ms |
|---|---|---|---|---|
| Qwen/Qwen2.5-3B-Instruct | 2/36 | 1.0 | 0.000518798828125 | 125.8 |
| Qwen/Qwen2.5-3B-Instruct | 2/36 | 1.0 | 0.000518798828125 | 125.0 |
| Qwen/Qwen2.5-7B-Instruct | 1/28 | 1.0 | 0.0014414787292480469 | 217.8 |

## 9. Limitations & disallowed claims
**Allowed:**
- real ModelScope Qwen checkpoints (no Hugging Face remote download)
- real tokenized prompt inputs (not only synthetic/random tokens)
- masked runtime path verified by audit flags and negative controls
- float32 / mixed-safe (bf16 load, fp32 fold/recover/compare) correctness under the tested settings
- explicit leakage accounting (token recovery, masked-logit alignment, hidden-state structure)

**Disallowed (must NOT claim):**
- production-ready TEE (this is a simulated TEE only)
- semantic security
- hiding sequence length
- hiding attention scores / probabilities
- full 3B/7B end-to-end generation unless actually run at full layers
- pure-bf16 exact correctness (mixed-safe fp32 recovery is required)

