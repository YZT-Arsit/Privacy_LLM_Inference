# Stage 8.2 — Real ModelScope Checkpoint Probe

- model_id: **Qwen/Qwen2.5-3B-Instruct**
- status: **ok**
- dtypes: model=**bfloat16** folding=**float32** runtime=**float32** recovery=**float32** | device: **cuda**
- cuda_available: **True** | device_name: **NVIDIA H800 PCIe**
- model_type: **qwen2** | total_layers: **36** | max_layers: **2** | partial: **True**
- hidden_size: **2048** | vocab_size: **151936**
- mask_mode: **signed_permutation** | strategy: **shared** | shared: **True**

> This stage runs bounded real ModelScope checkpoints through a masked runtime with a simulated TEE only. It does not use real TEE hardware, does not validate production generation, and claims no semantic, cryptographic, or formal security.

## Audit

- input_source: **prompt_file** | prompt_count: **8** | input_ids_shape: `[8, 128]`
- checkpoint_source: **ModelScope** | hf_remote_download_used: **False** | tokenizer_used: **True**
- layers: **2/36** | masked path used: embed=**True** blocks=**True** qkv=**True** mlp=**True** kv=**True** lm_head=**True** recovery=**True**
- negative_control: **none** | expected_to_match: **True** | negative_control_passed: **True**

## HF baseline (full model, greedy)

- latency_s: **0.7735** | tokens/s: **20.685**
- new_token_ids: `[2160, 432, 3204, 311, 990, 264, 220, 16, 17, 53, 11602, 311, 2355, 264, 220, 20]`
- text_head: `'Hello, please answer briefly: Is it possible to use a 12V battery to power a 5'`

## Extracted-weight plaintext reference

- latency_s: **0.1165** | num_tokens: **17**

## Masked runtime (simulated TEE)

- token_match_rate_vs_extracted: **1.0**
- recovered_logits_max_abs_error: **5.188e-04**
- masked_logits_max_abs_error: **8.812e-04**
- latency_s (incl. reference): **0.921**

## Mixed-precision diagnostics

| metric | value |
|---|---|
| `embedding_boundary_max_abs_err` | 0.0 |
| `layer_0_input_invariant_max_abs_err` | 0.0 |
| `layer_0_output_invariant_max_abs_err` | 1.594e-04 |
| `final_norm_core_max_abs_err` | 4.109e-04 |
| `masked_logits_max_abs_err` | 8.812e-04 |
| `recovered_logits_max_abs_err` | 5.188e-04 |
| `recovered_logits_mean_abs_err` | 1.213e-05 |
| `recovered_logits_relative_l2_err` | 4.939e-06 |
| `greedy_token_match_rate` | 1.000e+00 |
| `top1_min_margin` | 1.993e-04 |
| `top1_mean_margin` | 8.662e-01 |
| `positions_with_margin_below_error` | 1/1024 |

## Boundary accounting

| metric | value |
|---|---|
| `boundary_calls` | 34 |
| `tee_to_gpu_mb` | 0.5625 |
| `gpu_to_tee_mb` | 4.9265 |
| `handoff_gemm_count` | 0 |
| `handoff_gemm_flops` | 0 |
| `logits_recovery_flops` | 5165824 |

## Peak CUDA memory (masked phase)

- allocated_mb: 10082.77 MB
- reserved_mb: 19318.0 MB
- max_allocated_mb: 17738.93 MB
- max_reserved_mb: 19318.0 MB

## Caveats

- Simulated TEE only -- no real TEE hardware is used.
- mask_mode=signed_permutation: scalable + RMSNorm-compatible but weaker than dense orthogonal masking.
- residual_mask_strategy=shared: a shared residual mask is weaker than per-layer residual masks.
- Attention scores / probabilities remain GPU-visible.
- No semantic, cryptographic, or formal security is claimed.
- Extracted-weight reference (adjacent-pair RoPE); HF forward parity is diagnostic only (RoPE/cache conventions differ).
- max_layers < total: the extracted/masked stack is a PARTIAL model; HF baseline runs the full model, so HF tokens need not match the partial-stack tokens.

