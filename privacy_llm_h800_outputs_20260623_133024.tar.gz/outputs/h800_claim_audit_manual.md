| file | status | model | input | layers | masked | token_match | err | claim |
|---|---|---|---|---:|---:|---:|---:|---|
| h800_negative_plaintext_weights_qwen2_5_7b_layers4_realprompts_seq128_decode16.json | ok | Qwen/Qwen2.5-7B-Instruct | prompt_file [8, 128] | 4/28 | True |  |  | realprompt_partial_scalability_probe |
| h800_negative_wrong_vocab_qwen2_5_7b_layers4_realprompts_seq128_decode16.json | ok | Qwen/Qwen2.5-7B-Instruct | prompt_file [8, 128] | 4/28 | True |  |  | realprompt_partial_scalability_probe |
| h800_qwen2_5_3b_full_layers_realprompts_seq128_decode16_bf16_mixed_safe.json | ok | Qwen/Qwen2.5-3B-Instruct | prompt_file [8, 128] | 36/36 | True |  |  | realprompt_full_layer_probe |
| h800_qwen2_5_7b_layers16_realprompts_seq128_decode16_bf16_mixed_safe.json | ok | Qwen/Qwen2.5-7B-Instruct | prompt_file [8, 128] | 16/28 | True |  |  | realprompt_partial_scalability_probe |
| h800_qwen2_5_7b_layers1_realprompts_seq128_decode16_bf16_mixed_safe.json | ok | Qwen/Qwen2.5-7B-Instruct | prompt_file [8, 128] | 1/28 | True |  |  | realprompt_partial_scalability_probe |
| h800_qwen2_5_7b_layers2_realprompts_seq128_decode16_bf16_mixed_safe.json | ok | Qwen/Qwen2.5-7B-Instruct | prompt_file [8, 128] | 2/28 | True |  |  | realprompt_partial_scalability_probe |
| h800_qwen2_5_7b_layers4_realprompts_seq128_decode16_bf16_mixed_safe.json | ok | Qwen/Qwen2.5-7B-Instruct | prompt_file [8, 128] | 4/28 | True |  |  | realprompt_partial_scalability_probe |
| h800_qwen2_5_7b_layers8_realprompts_seq128_decode16_bf16_mixed_safe.json | ok | Qwen/Qwen2.5-7B-Instruct | prompt_file [8, 128] | 8/28 | True |  |  | realprompt_partial_scalability_probe |
| eval_7b_smoke_layers1_realprompt_bf16_mixed_safe.json | ok | Qwen/Qwen2.5-7B-Instruct | prompt_file [8, 128] | 1/28 | True |  |  | realprompt_partial_scalability_probe |
| eval_attack_masked_logits_0_5b_realprompts.json | ok | Qwen/Qwen2.5-0.5B-Instruct |   |  |  |  |  | other |
| eval_attack_token_recovery_0_5b_realprompts.json | ok | Qwen/Qwen2.5-0.5B-Instruct |   |  |  |  |  | other |
| eval_batch_scaling_0_5b_realprompts.json | ok | Qwen/Qwen2.5-0.5B-Instruct |   |  |  |  |  | other |
| eval_full_layer_0_5b_realprompts_seq128_decode16_bf16_mixed_safe.json | ok | Qwen/Qwen2.5-0.5B-Instruct | prompt_file [8, 128] | 24/24 | True |  |  | realprompt_full_layer_probe |
| eval_hidden_structure_leakage_0_5b_realprompts.json | ok | Qwen/Qwen2.5-0.5B-Instruct |   |  |  |  |  | other |
| eval_latency_0_5b_full_layers_realprompts.json | ok | Qwen/Qwen2.5-0.5B-Instruct | prompt_file [8, 128] | 24/24 | True |  |  | realprompt_full_layer_probe |
| eval_latency_0_5b_layers2_realprompts.json | ok | Qwen/Qwen2.5-0.5B-Instruct | prompt_file [8, 128] | 2/24 | True |  |  | realprompt_partial_scalability_probe |
| eval_latency_3b_layers2_realprompts.json | ok | Qwen/Qwen2.5-3B-Instruct | prompt_file [8, 128] | 2/36 | True |  |  | realprompt_partial_scalability_probe |
| eval_output_boundary_ablation_0_5b_realprompts.json | ok | Qwen/Qwen2.5-0.5B-Instruct |   |  |  |  |  | other |
| eval_realprompts_3b_layers2_seq128_decode16_bf16_mixed_safe.json | ok | Qwen/Qwen2.5-3B-Instruct | prompt_file [8, 128] | 2/36 | True |  |  | realprompt_partial_scalability_probe |
