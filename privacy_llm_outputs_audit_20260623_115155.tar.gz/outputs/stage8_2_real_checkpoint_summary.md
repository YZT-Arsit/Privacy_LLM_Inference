# Stage 8.2 — Real ModelScope Checkpoint Evidence Summary

## 1. Environment

- GPU: **NVIDIA GeForce RTX 5090 (32GB)**
- CUDA: **12.8** | torch: **2.8.0+cu128**
- Checkpoint source: **ModelScope only** (no Hugging Face remote download)
- Cache dir: `/root/autodl-tmp/modelscope_cache`
- Reports parsed: **31**

## 2. Main correctness table (float32 + bf16 mixed-safe)

| parameter_scale | precision_mode | dtype | folding_dtype | folded_weight_runtime_dtype | recovery_dtype | max_layers | total_layers | prefill_seq_len | decode_steps | mask_mode | residual_mask_strategy | status | token_match_rate_vs_extracted | recovered_logits_max_abs_err | recovered_logits_mean_abs_err | relative_l2_err | attention_mask_explicit | report_file |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 0.5B | float32 | float32 |  |  |  | 1 | 24 | 16 | 8 | signed_permutation | shared | ok | 1 | 0.0003266 |  |  |  | modelscope_qwen2_5_0_5b_stage8_2_float32.json |
| 1.5B | float32 | float32 |  |  |  | 2 | 28 | 16 | 8 | signed_permutation | shared | ok | 1 | 0.000319 |  |  |  | modelscope_qwen2_5_1_5b_stage8_2_float32.json |
| 3B | float32 | float32 |  |  |  | 2 | 36 | 16 | 8 | signed_permutation | shared | ok | 1 | 0.0001471 |  |  |  | modelscope_qwen2_5_3b_stage8_2_float32.json |
| 0.5B | bf16_mixed_safe | bfloat16 | float32 | float32 | float32 | 1 | 24 | 16 | 8 | signed_permutation | shared | ok | 1 | 0.0003266 | 9.621e-06 | 5.862e-06 | True | modelscope_qwen2_5_0_5b_bf16_mixed_safe.json |
| 1.5B | bf16_mixed_safe | bfloat16 | float32 | float32 | float32 | 2 | 28 | 16 | 8 | signed_permutation | shared | ok | 1 | 0.000319 | 1.424e-05 | 5.145e-06 | True | modelscope_qwen2_5_1_5b_bf16_mixed_safe.json |
| 3B | bf16_mixed_safe | bfloat16 | float32 | float32 | float32 | 2 | 36 | 16 | 8 | signed_permutation | shared | ok | 1 | 0.0001471 | 8.695e-06 | 3.483e-06 | True | modelscope_qwen2_5_3b_bf16_mixed_safe.json |

## 3. Low-precision ablation table

| parameter_scale | precision_mode | dtype | folding_dtype | folded_weight_runtime_dtype | recovery_dtype | status | token_match_rate_vs_extracted | recovered_logits_max_abs_err | report_file |
|---|---|---|---|---|---|---|---|---|---|
| 0.5B | float32 | float32 | float32 | float32 | float32 | ok | 1 | 0.0003266 | modelscope_qwen2_5_0_5b_float32_reference.json |
| 0.5B | bf16_mixed_safe | bfloat16 | float32 | float32 | float32 | ok | 1 | 0.0003266 | modelscope_qwen2_5_0_5b_bf16_mixed_safe.json |
| 0.5B | bf16_runtime_cast | bfloat16 | float32 | bfloat16 | float32 | ok | 0.7778 | 7.437 | modelscope_qwen2_5_0_5b_bf16_runtime_cast.json |
| 0.5B | bf16_all | bfloat16 | bfloat16 | bfloat16 | bfloat16 | ok | 0.6667 | 6.75 | modelscope_qwen2_5_0_5b_bf16_all_bf16.json |

- all-bf16 / runtime-cast may run but are NOT correctness-preserving.
- Casting folded masked weights or doing recovery in bf16 amplifies numerical drift.
- mixed-safe uses bf16 model load/execution where applicable but keeps folding / folded masked weights / recovery / comparison in fp32.

## 4. Main conclusion

- Float32 confirms algorithmic correctness of the real-checkpoint masked pipeline for Qwen2.5 0.5B, 1.5B, and 3B under the tested partial-layer settings (token_match_rate_vs_extracted = 1.0).
- Mixed-safe bf16 confirms numerically stable mixed-precision execution when folding and recovery are kept in fp32 (bf16 model load/execution, fp32 folding/folded-weights/recovery/comparison).
- Runtime-cast bf16 is a negative ablation: casting the folded masked weights to bf16 amplifies numerical drift and breaks exact token equivalence; it is NOT used as the correctness-preserving mode.

## 5. Limitations

- Simulated trusted runtime only; no actual TEE hardware.
- Partial-layer settings when max_layers < total layers (diagnostic, not a full-model run).
- Short prefill sequence length and short decode horizon.
- No semantic, cryptographic, or formal security is claimed.
- Attention scores, sequence length, and metadata are NOT hidden.
- Float32 is the correctness-validation setting; bf16 mixed-safe is an efficiency/scalability setting.
- ModelScope checkpoints only; no Hugging Face remote download.
- Output boundary is masked logits with trusted recovery/sampling.
- Mask: scalable signed-permutation (shared residual mask) is weaker than dense orthogonal / per-layer masking.

## 6. Paper-ready paragraph

We validate the masked-inference pipeline on real Qwen2.5 instruction checkpoints (0.5B, 1.5B, 3B) loaded locally through ModelScope (no Hugging Face remote download) on a single RTX 5090. Using extracted weights as a plaintext reference, the masked runtime -- a trusted embedding boundary, an untrusted masked decoder with scalable signed-permutation residual masks, and a masked-logits output boundary with trusted recovery and greedy sampling -- reproduces the reference next-token decisions exactly in float32 (token_match_rate = 1.0) under the tested partial-layer, short-horizon settings. A mixed-precision configuration that loads and runs the model in bfloat16 while keeping mask folding and logit recovery in float32 remains numerically stable and token-exact, whereas casting the folded masked weights themselves to bfloat16 amplifies drift and breaks exact token equivalence. We therefore report float32 as the correctness setting and bf16 mixed-safe as the efficiency setting; we make no semantic-security claim and use a simulated trusted runtime (no TEE hardware).

## 7. Claim audit

**Allowed claims:**
- Real ModelScope Qwen checkpoints loaded successfully.
- Masked pipeline matches the extracted plaintext reference in float32.
- Mixed-safe bf16 is numerically stable under the tested settings.
- Runtime-cast bf16 shows drift.

**Disallowed claims (must NOT be made):**
- Production-ready TEE.
- Semantic security.
- Full-model 7B correctness.
- Hidden sequence length.
- Hidden attention scores.
- Pure bf16 exact correctness.

## Expected input files

- `modelscope_qwen2_5_0_5b_stage8_2_float32.json`: **present**
- `modelscope_qwen2_5_1_5b_stage8_2_float32.json`: **present**
- `modelscope_qwen2_5_3b_stage8_2_float32.json`: **present**
- `modelscope_qwen2_5_0_5b_bf16_mixed_safe.json`: **present**
- `modelscope_qwen2_5_1_5b_bf16_mixed_safe.json`: **present**
- `modelscope_qwen2_5_3b_bf16_mixed_safe.json`: **present**
- `modelscope_qwen2_5_0_5b_float32_reference.json`: **present**
- `modelscope_qwen2_5_0_5b_bf16_runtime_cast.json`: **present**
- `modelscope_qwen2_5_0_5b_bf16_all_bf16.json`: **present**

