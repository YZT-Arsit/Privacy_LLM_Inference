# Stage 8.2 — Real ModelScope Checkpoint Probe

- model_id: **Qwen/Qwen2.5-0.5B-Instruct**
- status: **ok**
- dtypes: model=**bfloat16** folding=**float32** runtime=**float32** recovery=**float32** | device: **cuda**
- cuda_available: **True** | device_name: **NVIDIA GeForce RTX 5090**
- model_type: **qwen2** | total_layers: **24** | max_layers: **2** | partial: **True**
- hidden_size: **896** | vocab_size: **151936**
- mask_mode: **signed_permutation** | strategy: **shared** | shared: **True**

> This stage runs bounded real ModelScope checkpoints through a masked runtime with a simulated TEE only. It does not use real TEE hardware, does not validate production generation, and claims no semantic, cryptographic, or formal security.

## HF baseline (full model, greedy)

- latency_s: **0.6461** | tokens/s: **6.191**
- new_token_ids: `[3555, 374, 279, 1887]`
- text_head: `'Hello, please answer briefly: What is the main'`

## Extracted-weight plaintext reference

- latency_s: **0.0403** | num_tokens: **5**

## Masked runtime (simulated TEE)

- token_match_rate_vs_extracted: **1.0**
- recovered_logits_max_abs_error: **9.177e-04**
- masked_logits_max_abs_error: **1.446e-03**
- latency_s (incl. reference): **0.1189**

## Mixed-precision diagnostics

| metric | value |
|---|---|
| `embedding_boundary_max_abs_err` | 0.0 |
| `layer_0_input_invariant_max_abs_err` | 0.0 |
| `layer_0_output_invariant_max_abs_err` | 1.526e-04 |
| `final_norm_core_max_abs_err` | 5.264e-04 |
| `masked_logits_max_abs_err` | 1.446e-03 |
| `recovered_logits_max_abs_err` | 9.177e-04 |
| `recovered_logits_mean_abs_err` | 2.965e-05 |
| `recovered_logits_relative_l2_err` | 1.834e-05 |
| `greedy_token_match_rate` | 1.000e+00 |
| `top1_min_margin` | 7.077e-03 |
| `top1_mean_margin` | 8.752e-01 |
| `positions_with_margin_below_error` | 0/32 |

## Boundary accounting

| metric | value |
|---|---|
| `boundary_calls` | 10 |
| `tee_to_gpu_mb` | 0.0615 |
| `gpu_to_tee_mb` | 1.449 |
| `handoff_gemm_count` | 0 |
| `handoff_gemm_flops` | 0 |
| `logits_recovery_flops` | 1519360 |

## Peak CUDA memory (masked phase)

- allocated_mb: 2149.48 MB
- reserved_mb: 5194.0 MB
- max_allocated_mb: 4886.22 MB
- max_reserved_mb: 5194.0 MB

## Caveats

- Simulated TEE only -- no real TEE hardware is used.
- mask_mode=signed_permutation: scalable + RMSNorm-compatible but weaker than dense orthogonal masking.
- residual_mask_strategy=shared: a shared residual mask is weaker than per-layer residual masks.
- Attention scores / probabilities remain GPU-visible.
- No semantic, cryptographic, or formal security is claimed.
- Extracted-weight reference (adjacent-pair RoPE); HF forward parity is diagnostic only (RoPE/cache conventions differ).
- max_layers < total: the extracted/masked stack is a PARTIAL model; HF baseline runs the full model, so HF tokens need not match the partial-stack tokens.

