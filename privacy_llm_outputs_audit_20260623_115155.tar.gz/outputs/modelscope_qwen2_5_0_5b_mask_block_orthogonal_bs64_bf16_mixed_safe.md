# Stage 8.2 — Real ModelScope Checkpoint Probe

- model_id: **Qwen/Qwen2.5-0.5B-Instruct**
- status: **ok**
- dtypes: model=**bfloat16** folding=**float32** runtime=**float32** recovery=**float32** | device: **cuda**
- cuda_available: **True** | device_name: **NVIDIA GeForce RTX 5090**
- model_type: **qwen2** | total_layers: **24** | max_layers: **2** | partial: **True**
- hidden_size: **896** | vocab_size: **151936**
- mask_mode: **block_orthogonal** | strategy: **shared** | shared: **True**

> This stage runs bounded real ModelScope checkpoints through a masked runtime with a simulated TEE only. It does not use real TEE hardware, does not validate production generation, and claims no semantic, cryptographic, or formal security.

## HF baseline (full model, greedy)

- latency_s: **0.6609** | tokens/s: **12.105**
- new_token_ids: `[3555, 374, 279, 1887, 4522, 315, 419, 21085]`
- text_head: `'Hello, please answer briefly: What is the main idea of this passage'`

## Extracted-weight plaintext reference

- latency_s: **0.0494** | num_tokens: **9**

## Masked runtime (simulated TEE)

- token_match_rate_vs_extracted: **1.0**
- recovered_logits_max_abs_error: **9.255e-04**
- masked_logits_max_abs_error: **1.488e-03**
- latency_s (incl. reference): **0.159**

## Mixed-precision diagnostics

| metric | value |
|---|---|
| `embedding_boundary_max_abs_err` | 0.0 |
| `layer_0_input_invariant_max_abs_err` | 0.0 |
| `layer_0_output_invariant_max_abs_err` | 6.402e-05 |
| `final_norm_core_max_abs_err` | 2.371e-04 |
| `masked_logits_max_abs_err` | 1.488e-03 |
| `recovered_logits_max_abs_err` | 9.255e-04 |
| `recovered_logits_mean_abs_err` | 1.775e-05 |
| `recovered_logits_relative_l2_err` | 1.552e-05 |
| `greedy_token_match_rate` | 1.000e+00 |
| `top1_min_margin` | 1.456e-02 |
| `top1_mean_margin` | 1.093e+00 |
| `positions_with_margin_below_error` | 0/16 |

## Boundary accounting

| metric | value |
|---|---|
| `boundary_calls` | 18 |
| `tee_to_gpu_mb` | 0.041 |
| `gpu_to_tee_mb` | 2.6082 |
| `handoff_gemm_count` | 0 |
| `handoff_gemm_flops` | 0 |
| `logits_recovery_flops` | 2734848 |

## Peak CUDA memory (masked phase)

- allocated_mb: 2137.15 MB
- reserved_mb: 5188.0 MB
- max_allocated_mb: 4864.5 MB
- max_reserved_mb: 5188.0 MB

## Caveats

- Simulated TEE only -- no real TEE hardware is used.
- mask_mode=block_orthogonal: scalable + RMSNorm-compatible but weaker than dense orthogonal masking.
- residual_mask_strategy=shared: a shared residual mask is weaker than per-layer residual masks.
- Attention scores / probabilities remain GPU-visible.
- No semantic, cryptographic, or formal security is claimed.
- Extracted-weight reference (adjacent-pair RoPE); HF forward parity is diagnostic only (RoPE/cache conventions differ).
- max_layers < total: the extracted/masked stack is a PARTIAL model; HF baseline runs the full model, so HF tokens need not match the partial-stack tokens.

