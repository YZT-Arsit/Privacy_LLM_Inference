# Stage 8.2 — Real ModelScope Checkpoint Probe

- model_id: **Qwen/Qwen2.5-0.5B-Instruct**
- status: **ok**
- dtypes: model=**bfloat16** folding=**float32** runtime=**float32** recovery=**float32** | device: **cuda**
- cuda_available: **True** | device_name: **NVIDIA GeForce RTX 5090**
- model_type: **qwen2** | total_layers: **24** | max_layers: **24** | partial: **False**
- hidden_size: **896** | vocab_size: **151936**
- mask_mode: **signed_permutation** | strategy: **shared** | shared: **True**

> This stage runs bounded real ModelScope checkpoints through a masked runtime with a simulated TEE only. It does not use real TEE hardware, does not validate production generation, and claims no semantic, cryptographic, or formal security.

## Audit

- input_source: **prompt_file** | prompt_count: **8** | input_ids_shape: `[8, 128]`
- checkpoint_source: **ModelScope** | hf_remote_download_used: **False** | tokenizer_used: **True**
- layers: **24/24** | masked path used: embed=**True** blocks=**True** qkv=**True** mlp=**True** kv=**True** lm_head=**True** recovery=**True**
- negative_control: **none** | expected_to_match: **True** | negative_control_passed: **True**

## HF baseline (full model, greedy)

- latency_s: **0.8297** | tokens/s: **19.284**
- new_token_ids: `[3555, 374, 279, 1887, 4522, 315, 419, 21085, 30, 576, 1887, 4522, 315, 419, 21085, 374]`
- text_head: `'Hello, please answer briefly: What is the main idea of this passage? The main idea of this passage i'`

## Extracted-weight plaintext reference

- latency_s: **0.3028** | num_tokens: **17**

## Masked runtime (simulated TEE)

- token_match_rate_vs_extracted: **1.0**
- recovered_logits_max_abs_error: **3.622e-02**
- masked_logits_max_abs_error: **5.824e-02**
- latency_s (incl. reference): **1.0354**

## Mixed-precision diagnostics

| metric | value |
|---|---|
| `embedding_boundary_max_abs_err` | 0.0 |
| `layer_0_input_invariant_max_abs_err` | 0.0 |
| `layer_0_output_invariant_max_abs_err` | 7.808e-05 |
| `final_norm_core_max_abs_err` | 4.383e-02 |
| `masked_logits_max_abs_err` | 5.824e-02 |
| `recovered_logits_max_abs_err` | 3.622e-02 |
| `recovered_logits_mean_abs_err` | 1.963e-04 |
| `recovered_logits_relative_l2_err` | 2.042e-04 |
| `greedy_token_match_rate` | 1.000e+00 |
| `top1_min_margin` | 5.274e-04 |
| `top1_mean_margin` | 1.063e+00 |
| `positions_with_margin_below_error` | 38/1024 |

## Boundary accounting

| metric | value |
|---|---|
| `boundary_calls` | 34 |
| `tee_to_gpu_mb` | 0.2461 |
| `gpu_to_tee_mb` | 4.9265 |
| `handoff_gemm_count` | 0 |
| `handoff_gemm_flops` | 0 |
| `logits_recovery_flops` | 5165824 |

## Peak CUDA memory (masked phase)

- allocated_mb: 6497.86 MB
- reserved_mb: 16988.0 MB
- max_allocated_mb: 16362.84 MB
- max_reserved_mb: 16988.0 MB

## Caveats

- Simulated TEE only -- no real TEE hardware is used.
- mask_mode=signed_permutation: scalable + RMSNorm-compatible but weaker than dense orthogonal masking.
- residual_mask_strategy=shared: a shared residual mask is weaker than per-layer residual masks.
- Attention scores / probabilities remain GPU-visible.
- No semantic, cryptographic, or formal security is claimed.
- Extracted-weight reference (adjacent-pair RoPE); HF forward parity is diagnostic only (RoPE/cache conventions differ).

