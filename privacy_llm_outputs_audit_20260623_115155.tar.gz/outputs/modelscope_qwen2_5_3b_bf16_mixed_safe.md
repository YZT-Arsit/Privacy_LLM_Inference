# Stage 8.2 — Real ModelScope Checkpoint Probe

- model_id: **Qwen/Qwen2.5-3B-Instruct**
- status: **ok**
- dtypes: model=**bfloat16** folding=**float32** runtime=**float32** recovery=**float32** | device: **cuda**
- cuda_available: **True** | device_name: **NVIDIA GeForce RTX 5090**
- model_type: **qwen2** | total_layers: **36** | max_layers: **2** | partial: **True**
- hidden_size: **2048** | vocab_size: **151936**
- mask_mode: **signed_permutation** | strategy: **shared** | shared: **True**

> This stage runs bounded real ModelScope checkpoints through a masked runtime with a simulated TEE only. It does not use real TEE hardware, does not validate production generation, and claims no semantic, cryptographic, or formal security.

## HF baseline (full model, greedy)

- latency_s: **0.8498** | tokens/s: **9.414**
- new_token_ids: `[2160, 432, 3204, 311, 614, 264, 8225, 1372]`
- text_head: `'Hello, please answer briefly: Is it possible to have a negative number'`

## Extracted-weight plaintext reference

- latency_s: **0.0684** | num_tokens: **9**

## Masked runtime (simulated TEE)

- token_match_rate_vs_extracted: **1.0**
- recovered_logits_max_abs_error: **1.471e-04**
- masked_logits_max_abs_error: **2.452e-04**
- latency_s (incl. reference): **0.3338**

## Mixed-precision diagnostics

| metric | value |
|---|---|
| `embedding_boundary_max_abs_err` | 0.0 |
| `layer_0_input_invariant_max_abs_err` | 0.0 |
| `layer_0_output_invariant_max_abs_err` | 2.795e-05 |
| `final_norm_core_max_abs_err` | 4.268e-05 |
| `masked_logits_max_abs_err` | 2.452e-04 |
| `recovered_logits_max_abs_err` | 1.471e-04 |
| `recovered_logits_mean_abs_err` | 8.695e-06 |
| `recovered_logits_relative_l2_err` | 3.483e-06 |
| `greedy_token_match_rate` | 1.000e+00 |
| `top1_min_margin` | 3.742e-02 |
| `top1_mean_margin` | 7.604e-01 |
| `positions_with_margin_below_error` | 0/16 |

## Boundary accounting

| metric | value |
|---|---|
| `boundary_calls` | 18 |
| `tee_to_gpu_mb` | 0.0938 |
| `gpu_to_tee_mb` | 2.6082 |
| `handoff_gemm_count` | 0 |
| `handoff_gemm_flops` | 0 |
| `logits_recovery_flops` | 2734848 |

## Peak CUDA memory (masked phase)

- allocated_mb: 9022.68 MB
- reserved_mb: 16876.0 MB
- max_allocated_mb: 15564.48 MB
- max_reserved_mb: 16876.0 MB

## Caveats

- Simulated TEE only -- no real TEE hardware is used.
- mask_mode=signed_permutation: scalable + RMSNorm-compatible but weaker than dense orthogonal masking.
- residual_mask_strategy=shared: a shared residual mask is weaker than per-layer residual masks.
- Attention scores / probabilities remain GPU-visible.
- No semantic, cryptographic, or formal security is claimed.
- Extracted-weight reference (adjacent-pair RoPE); HF forward parity is diagnostic only (RoPE/cache conventions differ).
- max_layers < total: the extracted/masked stack is a PARTIAL model; HF baseline runs the full model, so HF tokens need not match the partial-stack tokens.

