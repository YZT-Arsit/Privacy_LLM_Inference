# Stage 8.2 — Real ModelScope Checkpoint Probe

- model_id: **Qwen/Qwen2.5-1.5B-Instruct**
- status: **ok**
- resolved_dtype: **float32** | device: **cuda**
- cuda_available: **True** | device_name: **NVIDIA GeForce RTX 5090**
- model_type: **qwen2** | total_layers: **28** | max_layers: **2** | partial: **True**
- hidden_size: **1536** | vocab_size: **151936**
- mask_mode: **signed_permutation** | strategy: **shared** | shared: **True**

> This stage runs bounded real ModelScope checkpoints through a masked runtime with a simulated TEE only. It does not use real TEE hardware, does not validate production generation, and claims no semantic, cryptographic, or formal security.

## HF baseline (full model, greedy)

- latency_s: **0.5653** | tokens/s: **14.152**
- new_token_ids: `[3555, 374, 279, 6722, 315, 9625, 5267, 785]`
- text_head: `'Hello, please answer briefly: What is the capital of France?\nThe'`

## Extracted-weight plaintext reference

- latency_s: **0.0391** | num_tokens: **9**

## Masked runtime (simulated TEE)

- token_match_rate_vs_extracted: **1.0**
- recovered_logits_max_abs_error: **3.190e-04**
- masked_logits_max_abs_error: **5.655e-04**
- latency_s (incl. reference): **0.182**

## Boundary accounting

| metric | value |
|---|---|
| `boundary_calls` | 18 |
| `tee_to_gpu_mb` | 0.1406 |
| `gpu_to_tee_mb` | 5.2163 |
| `handoff_gemm_count` | 0 |
| `handoff_gemm_flops` | 0 |
| `logits_recovery_flops` | 2734848 |

## Peak CUDA memory (masked phase)

- allocated_mb: 8075.21 MB
- reserved_mb: 13148.0 MB
- max_allocated_mb: 12896.63 MB
- max_reserved_mb: 13148.0 MB

## Caveats

- Simulated TEE only -- no real TEE hardware is used.
- mask_mode=signed_permutation: scalable + RMSNorm-compatible but weaker than dense orthogonal masking.
- residual_mask_strategy=shared: a shared residual mask is weaker than per-layer residual masks.
- Attention scores / probabilities remain GPU-visible.
- No semantic, cryptographic, or formal security is claimed.
- Extracted-weight reference (adjacent-pair RoPE); HF forward parity is diagnostic only (RoPE/cache conventions differ).
- max_layers < total: the extracted/masked stack is a PARTIAL model; HF baseline runs the full model, so HF tokens need not match the partial-stack tokens.

